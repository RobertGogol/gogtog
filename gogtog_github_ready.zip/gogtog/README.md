# gogtog

Debounced toggle-switch library for Arduino. Works with push buttons connected to a digital pin configured as `INPUT_PULLUP`.

## Behavior

- On falling edge (confirmed LOW): internal toggle flips between `0` and `1`
- Returns current toggle value (0 or 1) only when it changes
- Otherwise returns `-1` to indicate no change

## Example

```cpp
GogTog button(4, 5);
button.begin();

void loop() {
    int state = button.update();
    if (state != -1) {
        // use 0 or 1
    }
}
```

## Compatible with

- Arduino Uno
- Arduino Leonardo
