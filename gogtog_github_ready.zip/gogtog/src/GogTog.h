// Author: Robert Gogol <robert.gogol@gmail.com>
#ifndef GOGTOG_H
#define GOGTOG_H

#include <Arduino.h>

class GogTog {
public:
    GogTog(uint8_t pin, unsigned long debounceDelay = 5);
    void begin();
    int update(); // returns 0 or 1 on toggle, -1 if no change

private:
    uint8_t _pin;
    unsigned long _debounceDelay;
    bool _state;
    int _lastReading;
    int _stableReading;
    unsigned long _lastDebounceTime;
};

#endif
