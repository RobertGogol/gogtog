// Author: Robert Gogol <robert.gogol@gmail.com>
#include "GogTog.h"

GogTog::GogTog(uint8_t pin, unsigned long debounceDelay)
    : _pin(pin),
      _debounceDelay(debounceDelay),
      _state(false),
      _lastReading(HIGH),
      _stableReading(HIGH),
      _lastDebounceTime(0) {}

void GogTog::begin() {
    pinMode(_pin, INPUT_PULLUP);
}

int GogTog::update() {
    int currentReading = digitalRead(_pin);

    if (currentReading != _lastReading) {
        _lastDebounceTime = millis();
    }

    _lastReading = currentReading;

    if ((millis() - _lastDebounceTime) > _debounceDelay) {
        if (currentReading != _stableReading) {
            _stableReading = currentReading;

            if (_stableReading == LOW) {
                _state = !_state;
                return _state ? 1 : 0;
            }
        }
    }

    return -1; // no change
}
